##   ⦁═𝗤𝘂𝗲𝗲𝗻 👸 𝗔𝗹𝗲𝘅𝗮═⦁




 ![logo](https://telegra.ph/file/82e38f9dd5af4a28f975b.jpg) 

![My card name](https://cardivo.vercel.app/api?name=CUZIER%20-%20X&description=Hi,%25Welcome%25To%25My%20Profile%20❤&image=https://telegra.ph/file/82e38f9dd5af4a28f975b.jpg/images?q=tbn:ANd9GcR7aMC3bf4bg4l_nhYS2Un9FXbFYcB4T83Shjk8xSUZDh_D61LFpzbpeqLW&s=10?v=4&backgroundColor=%23ecf0f1&instagram=___En____Cuzier___&linkedin=___En____Cuzier___&github=Queen-Alexa&Whatsapp=@+94770828171&pattern=leaf&colorPattern=%23eaeaea)



[![Run on Repl.it](resources/gif/qr-scan.gif)](https://replit.com/@RavinduManoj/Queen-Sew-QR-Code)
<div align="center">
<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=manishkumar1601&show_icons=true&theme=nightowl" alt="Manish" /></p>

  <h1 align="center"><b> <p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api/top-langs/?username=manishkumar1601&theme=algolia&layout=compact&langs_count=10&hide_border=true&show_icons=true" alt="Manish"/></p></a><br> </b></h1>



**Visitors Count**  
![VisitorCount](https://profile-counter.glitch.me/{queenalexa2}/count.svg) 
                                                             
 [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/queenalexa2/queenalexa2)

       Special Tanks to 
@Toxic_devil @tharun_bro
